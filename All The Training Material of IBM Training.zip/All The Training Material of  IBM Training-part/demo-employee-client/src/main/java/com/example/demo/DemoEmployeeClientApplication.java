package com.example.demo;

import org.springframework.boot.SpringApplication;
import java.io.IOException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestClientException;

import com.example.client.ControllerEmployeeClient;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
@Configuration
//@ComponentScan({"com.example"})
public class DemoEmployeeClientApplication {

	public static void main(String[] args) throws RestClientException, IOException
	{
				
		ApplicationContext ctx = SpringApplication.run(
				DemoEmployeeClientApplication.class);
		
		ControllerEmployeeClient consumerControllerClient=ctx.getBean(ControllerEmployeeClient.class);
		
		consumerControllerClient.getEmployee();
		
	}

	@Bean
	public  ControllerEmployeeClient  consumerControllerClient()
	{
		return  new ControllerEmployeeClient();
	}

	}

