package in.ibm.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManagementSystemWithHibernateApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementSystemWithHibernateApplication.class, args);
	}

}
