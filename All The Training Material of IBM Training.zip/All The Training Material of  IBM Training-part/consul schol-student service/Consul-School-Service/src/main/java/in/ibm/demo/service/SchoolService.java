package in.ibm.demo.service;

import java.util.List;

public interface SchoolService {
	
	public List<Object> getStudents(String schoolName);

}
