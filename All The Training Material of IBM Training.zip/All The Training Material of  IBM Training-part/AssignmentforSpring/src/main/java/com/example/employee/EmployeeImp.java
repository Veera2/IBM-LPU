package com.example.employee;

import org.springframework.stereotype.Component;
import java.util.*;
import java.util.Map.Entry;


@Component
public class EmployeeImp implements Employeemng
{
	
	Map<Integer,Object> hm=new HashMap<Integer,Object>();
	
	@Override
	public void save(String empName, int empId, String empDept, float empSalary) 
	{
		
		hm.put(1, empName);
		hm.put(2, empId);
		hm.put(3, empDept);
		hm.put(4,empSalary);
	}

	Set<Entry<Integer, Object>> st =hm.entrySet();
	@Override
	public void list(String empName, int empId, String empDept, float empSalary)
	{
		    		  
	       for (Entry<Integer, Object> me:st) 
	       { 
	           System.out.print(me.getKey()+":"); 
	           System.out.println(me.getValue()); 
	       } 
		
	}
	

}
