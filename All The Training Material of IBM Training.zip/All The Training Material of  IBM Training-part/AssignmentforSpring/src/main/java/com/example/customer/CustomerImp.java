package com.example.customer;
import java.util.*;

import org.springframework.stereotype.Component;

@Component
public class CustomerImp  implements Customermng
{
	Set<Object> set=new HashSet<Object>();
	

	@Override
	public void save(int custId, String custName, String custQuery, float custRating)
	{
		
		set.add(custId);
		set.add(custName);	
		set.add(custQuery);
		set.add(custRating);
		
	}

	@Override
	public void list(int custId, String custName, String custQuery, float custRating)
	{
		// TODO Auto-generated method stub
		System.out.println(set);
	}

}
