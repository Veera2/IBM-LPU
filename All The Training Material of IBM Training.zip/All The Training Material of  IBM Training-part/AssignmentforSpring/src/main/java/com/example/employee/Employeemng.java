package com.example.employee;

public interface Employeemng 
{
String empName=null;
int empId=0;
String empDept=null;
float empSalary=0.0f;
public void save(String empName,int empId,String empDept,float empSalary);
public void list(String empName,int empId,String empDept,float empSalary);

}
