package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Import;

import com.example.customer.CustAppConfig;
import com.example.customer.Customermng;
import com.example.employee.EmpAppConfig;
import com.example.employee.Employeemng;
import com.example.invoice.InvoiceAppConfig;
import com.example.invoice.Invoicemng;

import java.util.Scanner;


@SpringBootApplication
@EnableAutoConfiguration
@ComponentScan({"com.example"})
@Import({DemoAppConfig.class})

public class Demo1Application {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int iTmp=99;
	ApplicationContext ctx=SpringApplication.run(DemoAppConfig.class);
	
		
	while(iTmp!=4)
	{
		System.out.println("1.Save and Display Employee\n2.Save and Display Customer\n3.Save and Display Invoice\n4.Exit");
		
		System.out.println("Enter your choice : ");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1: 
			try
			{
			
				Employeemng objEmploye=(Employeemng) ctx.getBean("EmployeeBean");		
				System.out.println("enter the name of the employee");
				String empName=sc.next();
				System.out.println("enter the employee id");
				int empId=sc.nextInt();
				System.out.println("enter the department of employee");
		        String empDept=sc.next();
				
				System.out.println("enter the salary of employee");
				float empSalary=sc.nextFloat();
				
				objEmploye.save(empName, empId, empDept, empSalary);
				objEmploye.list(empName, empId, empDept, empSalary);
				//sc.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
				break;
		case 2:
			try
			{  
			   System.out.println("enter the id of the customer");
			   int custId=sc.nextInt();
			   System.out.println("enter the name of the customer");
			   String custName=sc.next();
			   System.out.println("enter thr query of the customer");
			   String custQuery=sc.next();
			   System.out.println("enter the rating that customer want to give");
			   float custRating=sc.nextFloat();
			   
			   Customermng objCustomer= (Customermng) ctx.getBean("CustomerBean");
			   objCustomer.save(custId, custName, custQuery, custRating);
			   objCustomer.list(custId, custName, custQuery, custRating);
			}
			catch(Exception e)
			{
				e.printStackTrace();
				
			}
			   
			   break;
		case 3:
			try
			{
					  Invoicemng objInvoice=(Invoicemng) ctx.getBean("InvoiceBean");
					  objInvoice.save(); 
					  objInvoice.list();
					 }
			catch(Exception e)
			{
				e.printStackTrace();
			}
			break;
		case 4:break;
	
		}	
		
		}
		
	}

}
