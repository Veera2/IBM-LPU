package com.example.invoice;

public interface Invoicemng 
{
	public void save ();
public void list();

}
