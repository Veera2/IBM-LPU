package com.example.customer;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CustAppConfig 
{
@Bean(name="CustomerBean")
public Customermng method()
{
	return new CustomerImp();
}

}
