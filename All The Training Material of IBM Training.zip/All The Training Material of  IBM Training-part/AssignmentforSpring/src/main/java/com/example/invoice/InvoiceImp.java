package com.example.invoice;

import org.springframework.stereotype.Component;
import java.util.*;

@Component
public class InvoiceImp implements Invoicemng
{
	List<Object> list=new LinkedList<Object>();
	//Invoice objin=new Invoice();
	Iterator<Object> iter=list.iterator();
	Scanner sc=new Scanner(System.in);
	int inCost;
	String inDescription,inPayment;
	@Override
	public void save() {
		//String cost=String.valueOf(inCost);
		System.out.println("enter the cost of the bill");
		 inCost=sc.nextInt();
		list.add(inCost);
		
		System.out.println("enter the description of the bill");
		 inDescription=sc.next();
		 list.add(inDescription);
			
		
		System.out.println("wheter the buyer made the payment or not ");
		 inPayment=sc.next();
		 list.add(inPayment);
	}

	@Override
	public void list() 
	{
		System.out.println(list);
		/*
		 * while(iter.hasNext()) { Invoice objin=(Invoice) iter.next();
		 * objin.getInCost(); objin.getInDescription(); objin.getInPayment(); }
		 */
	}

	

}
