package com.example.customer;

public interface Customermng 
{
	int custId=0;
	String custName=null;
	String custQuery=null;
	float custRating=0.0f;
	
	public void save(int custId,String custName,String custQuery,float custRating);
	public void list(int custId,String custName,String custQuery,float custRating);
	
	

}
