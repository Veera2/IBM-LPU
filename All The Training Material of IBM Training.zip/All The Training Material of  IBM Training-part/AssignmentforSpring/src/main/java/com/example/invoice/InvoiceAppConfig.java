package com.example.invoice;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class InvoiceAppConfig 
{
@Bean(name="InvoiceBean")
public Invoicemng method()
{
	return new InvoiceImp();
}

}
