package com.example.demo;

import org.springframework.context.annotation.Import;

import com.example.customer.CustAppConfig;
import com.example.employee.EmpAppConfig;
import com.example.invoice.InvoiceAppConfig;

@Import({EmpAppConfig.class,CustAppConfig.class,InvoiceAppConfig.class})
public class DemoAppConfig {

}
