package com.example.invoice;

public class Invoice {
	

int inCost=0;
String inDescription=null;
String inPayment=null;
public Invoice()
{
	
}
public int getInCost() {
	return inCost;
}
public void setInCost(int inCost) {
	this.inCost = inCost;
}
public String getInDescription() {
	return inDescription;
}
public void setInDescription(String inDescription) {
	this.inDescription = inDescription;
}
public String getInPayment() {
	return inPayment;
}
public void setInPayment(String inPayment) {
	this.inPayment = inPayment;
}
public Invoice(int inCost, String inDescription, String inPayment) {
	super();
	this.inCost = inCost;
	this.inDescription = inDescription;
	this.inPayment = inPayment;
}


}
