package com.test.dao;



import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;


import com.test.model.Person;

@Component
public class PersonDAOimpl implements PersonDAO {
	
	 Logger logger = LoggerFactory.getLogger(PersonDAOimpl.class);
		
	
    
	private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    
   	@Override
	public void save(Person p) {
		Session session = this.sessionFactory.openSession();   
		Transaction tx = session.beginTransaction();
		session.persist(p);
		
		    logger.trace("A TRACE Message");
	        logger.debug("A DEBUG Message");
	        logger.debug("value of list emp-->"+p);
	        
	        logger.info("An INFO Message");
	        logger.warn("A WARN Message");
	        logger.error("An ERROR Message");
		tx.commit();
		session.close();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Person> list() {
		Session session = this.sessionFactory.openSession();
		List<Person> personList = session.createQuery("from Person").list();
		session.close();
		return personList;
	}

}
