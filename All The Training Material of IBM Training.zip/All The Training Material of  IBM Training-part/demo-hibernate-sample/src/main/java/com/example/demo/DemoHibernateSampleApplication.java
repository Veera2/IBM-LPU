// DemoApplicationClass Code 


package com.example.demo;

import java.util.List;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.test.dao.PersonDAO;
import com.test.model.Person;



@Configuration
@ComponentScan({"com.test"})
@SpringBootApplication
@EnableTransactionManagement
public class DemoHibernateSampleApplication {

	@Transactional
	public static void main(String[] args) {
		//SpringApplication.run(DemoTrainingKoeingSpringHibernateApplication.class, args);
		
    
	ApplicationContext context = new ClassPathXmlApplicationContext("spring4.xml");
		
		PersonDAO personDAO = context.getBean(PersonDAO.class);
		
		Person person = new Person();
		person.setName("Pankaj"); 
		person.setCountry("India");
		
		personDAO.save(person);
		
		System.out.println("Person::"+person);
		
		List<Person> list = personDAO.list();
		
		for(Person p : list){
			System.out.println("Person List::"+p);
		}
		
		//context.close();
		
	}
		
	}

