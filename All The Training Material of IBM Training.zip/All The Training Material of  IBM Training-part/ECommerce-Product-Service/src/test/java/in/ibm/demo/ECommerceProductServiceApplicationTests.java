package in.ibm.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ECommerceProductServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
