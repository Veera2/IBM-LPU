package fi.files;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import java.util.Scanner;
import java.io.Serializable;

public class Data implements Serializable  
{
	File objFile=new File("D:\\IBM\\test.txt");	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
