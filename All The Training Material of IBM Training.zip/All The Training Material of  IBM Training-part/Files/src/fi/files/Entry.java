package fi.files;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;

public class Entry 
{
	
	public static void fileAttributes()
	{
		try
		{
			File objFile=new File("E:\\IBMJava\\file.txt");
			if(!objFile.exists())
			{
				//objFile.mkdir();
				objFile.createNewFile();
				System.out.println("creating the file");
			}
			
			File [] arrFile=objFile.listFiles();
			for(File tmpFile : arrFile)
			{
				if(tmpFile.isDirectory())
					System.out.println("[ "+tmpFile.getName()+" ]");
				else
						System.out.println(tmpFile.getName());
			
											
			System.out.println("last modified: "+ new Date(tmpFile.lastModified()));
			}
		}
			
		catch(IOException e)
			{
				e.printStackTrace();
			
			}
		

		
	}
	
	private static void writeFile()
	{
		File objFile=new File("D:\\IBMJava\\file.txt");
		FileOutputStream fos=null;
		DataOutputStream dos=null;
		try
		{
			fos=new FileOutputStream(objFile);
			dos= new DataOutputStream(fos);
			
			dos.writeUTF("hello welcome to the file application");
			dos.writeInt(22);
			dos.writeBoolean(true);
			dos.writeFloat(2222.2f);
			
			System.out.println("file written");
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
			
			
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
		finally
		{
			try {
				if(dos!=null)
					dos.close();
				if(fos!=null)
					fos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
	

	
	private static void readFile()
	{
		FileInputStream fis=null;
		DataInputStream dis=null;
		
		try {
			File objFile=new File("D:\\IBMJava\\file.txt");
			fis=new FileInputStream("D:\\IBMJava\\file.txt");
			dis= new DataInputStream(fis);
			
			String str=dis.readUTF();
			int age=dis.readInt();
			boolean gender=dis.readBoolean();
			float salary=dis.readFloat();
			
			System.out.println(str);
			System.out.println(age);
			System.out.println(gender);
			System.out.println(salary);
						
		} catch (FileNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try {
				if(dis!=null)
					dis.close();
				if(fis!=null)
					fis.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
	private static void fileEncryption()
	{
		File objFile=new File("D:\\IBMJava\\some.txt");
		FileOutputStream fos=null;
		FileInputStream fis=null;
		
		try {
			
			fis=new FileInputStream("D:\\IBMJava\\some.txt");
			
			byte [] data=new byte[(int)objFile.length()];
			fis.read(data);
			fos=new FileOutputStream("D:\\IBMJava\\some-enc.txt");
		
			
			
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private static void fileDecryption()
	{
		//File objFile=new File("D:\\IBMJava\\")
	}
		public static void main(String args[])
	{
		fileAttributes();
		writeFile();
		readFile();
		fileEncryption();
		fileDecryption();
				
		}
	}


