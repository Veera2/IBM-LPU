package org.fi.util;

public class Manager extends Employee
{
	protected float HRA;

	public Manager(String name, String adress, boolean gender, int age, float basicSalary,float HRA)
	{
		super(name, adress, gender, age, basicSalary);
		this.HRA=HRA;
		
		// TODO Auto-generated constructor stub
	}

	public float getHra() {
		return HRA;
	}

	public void setHRA(float Hra) {
		HRA = Hra;
	}

}
