package org.fi.util;
public class Engineer extends Employee
{
protected float OverTime;
	public Engineer(String name, String adress, boolean gender, int age, float basicSalary,float OverTime)
		{
		super(name, adress, gender, age, basicSalary);
		this.OverTime=OverTime;
		// TODO Auto-generated constructor stub
		}
	public float getOverTime() {
		return OverTime;
	}
	public void setOverTime(float overTime) {
		OverTime = overTime;
	}
	
	
	

}
