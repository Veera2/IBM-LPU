package org.fi.util;

public class SalesPerson extends Employee 
{
protected int commission;
	public SalesPerson(String name, String adress, boolean gender, int age, float basicSalary,int commission) {
		super(name, adress, gender, age, basicSalary);
		// TODO Auto-generated constructor stub
		this.commission=commission;
	}
	public int getCommission() {
		return commission;
	}
	public void setCommission(int commission) {
		this.commission = commission;
	}
	

}
