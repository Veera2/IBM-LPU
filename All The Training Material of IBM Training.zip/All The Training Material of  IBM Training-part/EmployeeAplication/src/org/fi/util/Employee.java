package org.fi.util;

public abstract class  Employee
{
	protected String name;
	protected String adress;
	protected boolean gender;
	protected int age;
	protected float basicSalary;
	
	public Employee(String name,String adress,boolean gender,int age,float basicSalary)
	{
		this.name=name;
		this.adress=adress;
		this.gender=gender;
		this.age=age;
		this.basicSalary=basicSalary;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAdress() {
		return adress;
	}
	public void setAdress(String adress) {
		this.adress = adress;
	}
	public boolean isGender() {
		return gender;
	}
	public void setGender(boolean gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public float getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(float basicSalary) {
		this.basicSalary = basicSalary;
	}

}
