package org.fi.util;
import java.io.FileInputStream;


import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.fi.utils.ConsoleInput;
import fi.utility.LinkedList;
public class Entry {
	
	

	public static void main(String[] args)
	{
		
		LinkedList <Employee>objList=new LinkedList<>();
		
		int index=0;
		
		
		
		
		  System.out.println("would you like to enter 1 for yes 2 for no"); 
		  int temp=ConsoleInput.getInt();
		 
		while(temp==1)
		{
				
			System.out.println("1.Add an Employee\n2.Dispaly\n3.Navigate\n4.Edit\n5.Store\n6.Exit");
			System.out.println("enter your choice");
			int ch=ConsoleInput.getInt();
			
			
				switch(ch)
					{
						case 1 : 
						{
							int iTemp1=99;
								while(iTemp1!=4)
							{
								System.out.println("1.Manager\n2.Engineer\n3.SalesPerson\n4.back");
								System.out.println("enter you choice");
								 iTemp1=ConsoleInput.getInt();
								switch(iTemp1)
								{
								case 1 :  
										System.out.println("enter name");
									  String name=ConsoleInput.getString();
									  System.out.println("Enter adress");
									  String adress=ConsoleInput.getString();
									  System.out.println("enter age");
									  int age=ConsoleInput.getInt();
									  System.out.println("enter gender");
									  boolean gender=ConsoleInput.getBoolean();
									  System.out.println("enter BasicSalary");
									  float basicSalary=ConsoleInput.getFloat();
									  System.out.println("enter HRA");
									  float HRA=ConsoleInput.getFloat();
									  //[index++]
									  Manager objManager=new Manager( name,adress,gender,age,basicSalary,HRA);
										objList.addNode(objManager);
								
										  break;
								case 2 : 
										  System.out.println("enter name");
										  name=ConsoleInput.getString();
										  System.out.println("Enter adress");
										  adress=ConsoleInput.getString();
										  System.out.println("enter age");
										  age=ConsoleInput.getInt();
										  System.out.println("enter gender");
										  gender=ConsoleInput.getBoolean();
										  System.out.println("enter BasicSalary");
										  basicSalary=ConsoleInput.getFloat();
										  System.out.println("enter OverTime");
										  float OverTime=ConsoleInput.getFloat();
										  //arrEmploye[index++]
										  Engineer objEngineer=new Engineer(name,adress,gender,age,basicSalary,OverTime);
										  objList.addNode(objEngineer);
										  break;
								case 3 : 
										  System.out.println("enter name");
										  name=ConsoleInput.getString();
										  System.out.println("Enter adress");
										  adress=ConsoleInput.getString();
										  System.out.println("enter age");
										  age=ConsoleInput.getInt();
										  System.out.println("enter gender");
										  gender=ConsoleInput.getBoolean();
										  System.out.println("enter BasicSalary");
										  basicSalary=ConsoleInput.getFloat();
										  System.out.println("enter commission");
										  int commission=ConsoleInput.getInt();
										  //arrEmploye[index++]=
										  SalesPerson objSalesPerson=new SalesPerson(name,adress,gender,age,basicSalary,commission);
										  objList.addNode(objSalesPerson);
										  break;
								case 4 :  break;	
								default:  System.out.println("check the input");
										
								}
												
								
								}
							break;
						}
						
								
case 2 : 
					{
						
						int iTemp2=11;
						while(iTemp2!=5)
					
						{     
							Employee objEmployee=objList.getFirst();
						    System.out.println("1.All\n2.Manager\n3.Engineer\n4.SalesPerson\n5.Back");
							System.out.println("Enter your choice");
							iTemp2=ConsoleInput.getInt();
							switch(iTemp2)
							{
								
						case 1:   
							while(objEmployee!=null)
							{
							System.out.println(objEmployee.getName());
							System.out.println(objEmployee.getAdress());
							System.out.println(objEmployee.getAge());
							System.out.println(objEmployee.isGender());
							System.out.println(objEmployee.getBasicSalary());
							if(objEmployee instanceof Manager)
							{
								Manager objManager=(Manager)objEmployee;
								System.out.println(objManager.getHra());
							}
							else if(objEmployee instanceof Engineer)
							{
								Engineer objEngineer=(Engineer)objEmployee;
								System.out.println(objEngineer.getOverTime());
							}
							else 
							{
								SalesPerson objSalesPerson=(SalesPerson)objEmployee;
								System.out.println(objSalesPerson.getCommission());
							}
							 objEmployee=objList.getNext();
							  //break;
							}
							break;
							
						case 2:
							while(objEmployee!=null)
							{
								if(objEmployee instanceof Manager)
								{
									Manager objManager=(Manager)objEmployee;
									System.out.println(objManager.getName());
									System.out.println(objManager.getAdress());
									System.out.println(objManager.getAge());
									System.out.println(objManager.isGender());
									System.out.println(objManager.getBasicSalary());
									System.out.println(objManager.getHra());
								}
								objEmployee=objList.getNext();
							}
							break;
						case 3 :while(objEmployee!=null)
							{
								if(objEmployee instanceof Engineer)
								{
									Engineer objEngineer=(Engineer)objEmployee;
									System.out.println(objEngineer.getName());
									System.out.println(objEngineer.getAdress());
									System.out.println(objEngineer.getAge());
									System.out.println(objEngineer.isGender());
									System.out.println(objEngineer.getBasicSalary());
									System.out.println(objEngineer.getOverTime());
								}
								objEmployee=objList.getNext();
							}	break;
						case 4 : while(objEmployee!=null)
							{
								if(objEmployee instanceof SalesPerson)
								{
									SalesPerson objSalesPerson=(SalesPerson)objEmployee;
									System.out.println(objSalesPerson.getName());
									System.out.println(objSalesPerson.getAdress());
									System.out.println(objSalesPerson.getAge());
									System.out.println(objSalesPerson.isGender());
									System.out.println(objSalesPerson.getBasicSalary());
									System.out.println(objSalesPerson.getCommission());
								}
								objEmployee=objList.getNext();
							}	break;
						case 5: break;
							
							}
						
				         }
					break;
					}
case 3 :
				{ int iTemp3=34;
				while(iTemp3!=5)
					{     
				
					System.out.println("1.First\n2.Previous\n3.next\n4.Last\n5.Back");
					System.out.println("Enter your choice");
					iTemp3=ConsoleInput.getInt();
						
					switch(iTemp3)
					{
						
						
					case 1 : if(objList.getFirst()!=null)
							{
							Employee objEmployee=(Employee)objList.getFirst();
							System.out.println(objEmployee.getName());
							System.out.println(objEmployee.getAdress());
							System.out.println(objEmployee.getAge());
							System.out.println(objEmployee.isGender());
							System.out.println(objEmployee.getBasicSalary());
								if(objEmployee instanceof Manager)
							{
								Manager objManager=(Manager)objEmployee;
								System.out.println(objManager.getHra());
							}
							else if(objEmployee instanceof Engineer)
							{
								Engineer objEngineer=(Engineer)objEmployee;
								System.out.println(objEngineer.getOverTime());
							}
							else 
							{
								SalesPerson objSalesPerson=(SalesPerson)objEmployee;
								System.out.println(objSalesPerson.getCommission());
							}
							//objEmployee=(Employee)objList.getNext();
							
							}
							break;
							
					case 2 :
							{
							Employee objEmployee =  objList.getPrevious();
							
							System.out.print("Name:");
							System.out.println(objEmployee.getName());
							System.out.print("Address:");
							System.out.println(objEmployee.getAdress());
							System.out.print("Age:");
							System.out.println(objEmployee.getAge());
							System.out.print("Gender:");
							System.out.println(objEmployee.isGender());
							System.out.print("Basic Salary:");
								System.out.println(objEmployee.getBasicSalary());
							if (objEmployee instanceof Manager) {
								Manager objManager = (Manager) objEmployee;
								System.out.println(objManager.getHra());
							} else if (objEmployee instanceof Engineer) {
								Engineer objEngineer = (Engineer) objEmployee;
								System.out.println(objEngineer.getOverTime());
							}

							else {
								SalesPerson objSalesPerson = (SalesPerson) objEmployee;
								System.out.println(objSalesPerson.getCommission());
								}

							break;
								}
					case 3 : 
							{
						Employee objEmployee =  objList.getNext();
						System.out.print("Name:");
						System.out.println(objEmployee.getName());
						System.out.print("Address:");
						System.out.println(objEmployee.getAdress());
						System.out.print("Age:");
						System.out.println(objEmployee.getAge());
						System.out.print("Gender:");
						System.out.println(objEmployee.isGender());
						System.out.print("Basic Salary:");
						System.out.println(objEmployee.getBasicSalary());
						if (objEmployee instanceof Manager) {
							Manager objManager = (Manager) objEmployee;
							System.out.println(objManager.getHra());
						} else if (objEmployee instanceof Engineer) {
							Engineer objEngineer = (Engineer) objEmployee;
							System.out.println(objEngineer.getOverTime());
						}

						else {
							SalesPerson objSalesPerson = (SalesPerson) objEmployee;
							System.out.println(objSalesPerson.getCommission());
							}

							break;
							}
					case 4 :
							{

						Employee objEmployee =  objList.getLast();
						System.out.print("Name:");
						System.out.println(objEmployee.getName());
						System.out.print("Address:");
						System.out.println(objEmployee.getAdress());
						System.out.print("Age:");
						System.out.println(objEmployee.getAge());
						System.out.print("Gender:");
						System.out.println(objEmployee.isGender());
						System.out.print("Basic Salary:");
						System.out.println(objEmployee.getBasicSalary());
						if (objEmployee instanceof Manager) {
							Manager objManager = (Manager) objEmployee;
							System.out.println(objManager.getHra());
						} else if (objEmployee instanceof Engineer) {
							Engineer objEngineer = (Engineer) objEmployee;
							System.out.println(objEngineer.getOverTime());
						} else {
							SalesPerson objSalesPerson = (SalesPerson) objEmployee;
							System.out.println(objSalesPerson.getCommission());
						}
						break;
							}
					case 5 :break;
						}
					
					}
					break;
}
case 4 :  
{		int iTemp4=454;
		Employee objEmployee=objList.getFirst();
					while(iTemp4!=4)
						{
						
						index=0;
					    System.out.println("1.DeletebyName\n2.Updatealldata\n3.sort \n4.Back");
						System.out.println("Enter your choice");
						iTemp4=ConsoleInput.getInt();
						switch(iTemp4)
						{
							case 1:{
										System.out.println("enter the name you want to search and delete");
										String searchName=ConsoleInput.getString();
								
									if(objEmployee.getName().equalsIgnoreCase(searchName))
									{
										objList.deleteNode(index);
										System.out.println("deletion successful");
										
									}
									objEmployee=objList.getNext();
									index++;
							}
								
									break;
						    case 2:
						    {
								System.out.println("enter the name you want to search and update");
								String name=ConsoleInput.getString();
									
										
										if(objEmployee.getName().equalsIgnoreCase(name))
										{
											//System.out.println(objEmployee.getName());
											System.out.println("enter the addess");
											String adress=ConsoleInput.getString();
											objEmployee.setAdress(adress);
											System.out.println("enter the age");
											int age=ConsoleInput.getInt();
											objEmployee.setAge(age);
											System.out.println("enter the gender");
											boolean gender=ConsoleInput.getBoolean();
											objEmployee.setGender(gender);
											System.out.println("enter the basicsalary");
											float basicSalary=ConsoleInput.getFloat();
											objEmployee.setBasicSalary(basicSalary);
											
											
											if(objEmployee instanceof Manager)
											{
												Manager objManager=(Manager)objEmployee;
												System.out.println("enter Hra");
												float Hra=ConsoleInput.getFloat();
												((Manager) objEmployee).setHRA(Hra);
												
												
											}
											else if(objEmployee instanceof Engineer)
											{
												Engineer objEngineer=(Engineer)objEmployee;
												System.out.println("enter OverTime");
												float overTime=ConsoleInput.getFloat();
												((Engineer) objEmployee).setOverTime(overTime);
												
											}
											else 
											{
												SalesPerson objSalesPerson=(SalesPerson)objEmployee;
												System.out.println("enter commission");
												int commission=ConsoleInput.getInt();
												((SalesPerson) objEmployee).setCommission(commission);
												
											}
											
											
										}
										 objEmployee=objList.getNext();
										
						    }
										break;
						
							case 3:
							{
								
							 objEmployee=objList.getFirst();
							 List<String>list=new ArrayList<>();
							 //list.add(objEmployee.getName());
							 if(objEmployee instanceof Manager)
								{
									Manager objManager=(Manager)objEmployee;
									list.add(objManager.getName());
								}
							 if(objEmployee instanceof Engineer)
								{
									Engineer objEngineer=(Engineer)objEmployee;
									list.add(objEngineer.getName());
								}
							 if(objEmployee instanceof SalesPerson)
								{
									SalesPerson objSalesPerson=(SalesPerson)objEmployee;
									list.add(objSalesPerson.getName());
								}
							 objEmployee=objList.getNext();
							 Collections.sort(list);
						  Iterator<String>iter=list.iterator(); while(iter.hasNext()) {
						  System.out.println(iter.next()); 
						  }
						  
						 
								
							}
								break;
							case 4:break;
						
				
								}
						
							}
					
						break;
}
case 5 :
{
				int iTmp5=998;
				Employee objEmployee=objList.getFirst();
				while(iTmp5!=3)
				{
					System.out.println("1.Save\n2.Load\n3.Back");
					iTmp5=ConsoleInput.getInt();
					switch(iTmp5)
					{
					case 1:
						/*
						 * FileOutputStream fos=null; ObjectOutputStream oos=null;
						 * 
						 * try { while(objEmployee!=null) { objEmployee.getName();
						 * objEmployee.getAdress(); objEmployee.getAge(); objEmployee.isGender();
						 * objEmployee.getBasicSalary(); if(objEmployee instanceof Manager) { Manager
						 * objManager=(Manager)objEmployee; objManager.getHra();
						 * 
						 * } else if(objEmployee instanceof Engineer) { Engineer
						 * objEngineer=(Engineer)objEmployee; objEngineer.getOverTime(); } else {
						 * SalesPerson objSalesPerson=(SalesPerson)objEmployee;
						 * objSalesPerson.getCommission(); } objEmployee=objList.getNext(); //break; }
						 * fos=new FileOutputStream("D:\\IBMJava\\employee.txt"); oos=new
						 * ObjectOutputStream(fos); oos.writeObject(objEmployee);
						 * System.out.println("object stored"); } catch (FileNotFoundException e) { //
						 * TODO Auto-generated catch block e.printStackTrace(); } catch (IOException e)
						 * { // TODO Auto-generated catch block e.printStackTrace(); } finally { try {
						 * if(oos!=null) oos.close(); if(fos!=null) fos.close(); } catch (IOException e)
						 * { // TODO Auto-generated catch block e.printStackTrace(); } }
						 */	
						try(Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/java","root","123Veera!");
						Statement stselect=connection.createStatement();
								PreparedStatement psinsert=connection.prepareStatement("insert into manager values(?,?,?,?,?,?)");
								Scanner sc=new Scanner(System.in))
						{
							psinsert.clearParameters();
							
								try {
									Manager objManager=(Manager)objEmployee;
									psinsert.setString(1, objManager.getName());
									psinsert.setString(2, objManager.getAdress());
									psinsert.setInt(3, objManager.getAge());
									psinsert.setBoolean(4, objManager.isGender());
									psinsert.setFloat(5, objManager.getBasicSalary());
									psinsert.setFloat(6, objManager.getHra());
									psinsert.executeUpdate();
									System.out.println("Database succesfuly updated");
								} catch (SQLException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							
							
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						  break;
					case 2:
							FileInputStream fis=null;
							ObjectInputStream ois=null;
							
						try {
							fis=new FileInputStream("D:\\IBMJava\\employee.txt");
							ois=new ObjectInputStream(fis);
							
							
									/*
									 * Object data=ois.readObject(); objList=(LinkedList)data;
									 */
								 objEmployee=objList.getFirst();
								 while(objEmployee!=null)
								 {
									
									System.out.println(objEmployee.getName());
									System.out.println(objEmployee.getAdress());
									System.out.println(objEmployee.getAge());
									System.out.println(objEmployee.isGender());
									System.out.println(objEmployee.getBasicSalary());
									if(objEmployee instanceof Manager)
									{
										Manager objManager=(Manager)objEmployee;
										System.out.println(objManager.getHra());
									}
									else if(objEmployee instanceof Engineer)
									{
										Engineer objEngineer=(Engineer)objEmployee;
										System.out.println(objEngineer.getOverTime());
									}
									else 
									{
										SalesPerson objSalesPerson=(SalesPerson)objEmployee;
										System.out.println(objSalesPerson.getCommission());
									}
									 objEmployee=objList.getNext();
									  //break;
								 }
								
								
						} catch (FileNotFoundException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							} /*
								 * catch (ClassNotFoundException e) { // TODO Auto-generated catch block
								 * e.printStackTrace(); }
								 */ catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						finally
						{
							try {
								if(ois!=null)
									ois.close();
								if(fis!=null)
									fis.close();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					
							break;
					case 3:break;
					}
				}
}
				
						break;
case 6 :  break;

						
}
			

	}

}
	
}




