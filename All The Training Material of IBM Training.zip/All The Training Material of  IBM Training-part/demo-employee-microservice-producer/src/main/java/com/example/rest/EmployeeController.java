package com.example.rest;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Employee;

@RestController
public class EmployeeController 
{

	@RequestMapping(method=RequestMethod.GET,value="/employee")
	public Employee firstpage()
	{
		Employee objEmp=new Employee();
		objEmp.setName("veeranjaneyulu");
		objEmp.setEmpId(12);
		objEmp.setDesignation("manager");
		objEmp.setSalary(50000);
		return objEmp;
		
	}
}
