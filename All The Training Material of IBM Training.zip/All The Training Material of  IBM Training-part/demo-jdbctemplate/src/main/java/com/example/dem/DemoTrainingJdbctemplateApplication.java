

 package com.example.dem;
 

import java.util.List;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.example.DTO.Customer;
import com.example.DTO.Employee;
import com.example.DTO.Invoice;
import com.example.service.CustomerImpl2;
import com.example.service.EmployeeImpl2;
import com.example.service.InvoiceImpl2;

@Configuration
@EnableWebMvc
@ComponentScan({"com.example.restController"})
@SpringBootApplication
public class DemoTrainingJdbctemplateApplication {

	public static void main(String[] args) {
		
		//SpringApplication.run(DemoTrainingJdbctemplateApplication.class, args);
		//SpringApplication.run(DemoTrainingKoeingJdbcTemplateApplication.class, args);
		
		SpringApplication.run(DemoAppConfig.class, args);
	}
}
		
		
		//ApplicationContext context=SpringApplication.run(DemoAppConfig.class, args);
		
		
		// remaining code will write after the break
		
		// perform operation @Employee
	
		/*
	EmployeeImpl2 employeeJDBCTemplate = context.getBean(EmployeeImpl2.class);
	CustomerImpl2 customerJDBCTemplate=context.getBean(CustomerImpl2.class);
	InvoiceImpl2 invoiceJDBCTemplate=context.getBean(InvoiceImpl2.class);
				
	// method call here 
	runEmployeeCRUD(employeeJDBCTemplate);
	runCustomerCRUD(customerJDBCTemplate);
	runInvoiceCRUD(invoiceJDBCTemplate);
	
	}
	
	
	
	
    public static void runEmployeeCRUD(EmployeeImpl2 	employeeJDBCTemplate)
    {
			
		// create the employee data 
		
          employeeJDBCTemplate.setDB();
		
		System.out.println("------Records Creation--------");
		employeeJDBCTemplate.createEmpService("veera", 11);
		employeeJDBCTemplate.createEmpService("ram", 2);
		employeeJDBCTemplate.createEmpService("sunitha", 15);

		System.out.println("------Listing Multiple Records--------");
		List<Employee> employees = employeeJDBCTemplate.listEmployeeservice();
		for (Employee record : employees) {
			System.out.print("ID : " + record.getId());
			System.out.print(", Name : " + record.getName());
			System.out.println(", Age : " + record.getAge());
		}
		

		System.out.println("----Updating Record with ID = 2 -----");
		employeeJDBCTemplate.updateEmpService(2, 20);
		

		System.out.println("----Listing Record with ID = 2 -----");
	
		Employee employee = employeeJDBCTemplate.getEmployeeService(2);
		System.out.print("ID : " + employee.getId());
		System.out.print(", Name : " + employee.getName());
		System.out.println(", Age : " + employee.getAge());
		
		System.out.println("--------Deleteting the record with id=2------");
		employeeJDBCTemplate.deleteEmpService(2);
		

		
		
	}
    public static void runCustomerCRUD(CustomerImpl2 customerJDBCTemplate)
    {
    	customerJDBCTemplate.setDB();
    	System.out.println("******customer Record creation********");
    	customerJDBCTemplate.createService("Rajesh", 21);
    	customerJDBCTemplate.createService("srilakshmi", 25);
    	customerJDBCTemplate.createService("anitha", 20);
    	customerJDBCTemplate.createService("nagalakshmi", 23);
    	
    	System.out.println("*****Listing multiple records of customer********");
    	List<Customer> customers=customerJDBCTemplate.listCustomerService();
    	for(Customer record: customers)
    	{
    		System.out.print("ID : " + record.getId());
			System.out.print(", Name : " + record.getName());
			System.out.println(", Age : " + record.getAge());
    	
    	}
    	
    	System.out.println("******************UPDATED RECORD WITH ID=3*********");
    	customerJDBCTemplate.updateService(3, 19);
    	
    	System.out.println("*************LISTING RECORD WITH ID=3******");
    	Customer customer=customerJDBCTemplate.getCustomerService(3);
    	System.out.print("ID : " + customer.getId());
		System.out.print(", Name : " + customer.getName());
		System.out.println(", Age : " + customer.getAge());
		
		System.out.println("*****Deleting Record with id=3");
		customerJDBCTemplate.deleteService(2);
    	
    	
    	
    }
    public static void runInvoiceCRUD(InvoiceImpl2 invoiceJDBCTemplate)
    {
    	invoiceJDBCTemplate.setDB();
    	System.out.println("++++++++Invoice Record Creation++++++");
    	invoiceJDBCTemplate.createService("vali", 21);
    	invoiceJDBCTemplate.createService("manoj", 22);
    	invoiceJDBCTemplate.createService("Koushik", 21);
    	
    	System.out.println("+++++++Listing multiple records+++++++");
    	List<Invoice> invoices=invoiceJDBCTemplate.listInvoiceService();
    	for(Invoice record: invoices)
    	{
    		System.out.print("ID : " + record.getId());
			System.out.print(", Name : " + record.getName());
			System.out.println(", Age : " + record.getAge());
    	}
    	
    	System.out.println("+++++++Updating Record with ID = 2+++++++");
    	invoiceJDBCTemplate.updateService(2, 20);
		

		System.out.println("+++++++Listing Record with ID = 2 ++++++++");
	
		Invoice invoice= invoiceJDBCTemplate.getInvoiceService(2);
		System.out.print("ID : " + invoice.getId());
		System.out.print(", Name : " + invoice.getName());
		System.out.println(", Age : " + invoice.getAge());
		
		System.out.println("+++++++Deleteting the record with id=2++++++");
		invoiceJDBCTemplate.deleteService(1);
    }
	*/

	

