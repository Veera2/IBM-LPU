package com.example.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.DAO.CustomerImpDAO;

import com.example.DTO.Customer;

@Service
public class CustomerImpl2 implements CustomerService 
{
@Autowired
private CustomerImpDAO objCust;

public void setDB()
{
	objCust.setupDB();
}

@Override
public void createService(String name, Integer age) {
	// TODO Auto-generated method stub
objCust.create(name, age);
}
	@Override
	public Customer getCustomerService(Integer id) {
		// TODO Auto-generated method stub
		return objCust.getCustomer(id);
	}

	@Override
	public List<Customer> listCustomerService() {
		// TODO Auto-generated method stub
		return objCust.listCustomer();
	}

	@Override
	public void deleteService(Integer id) {
		// TODO Auto-generated method stub
		
		objCust.delete(id);
	}

	@Override
	public void updateService(Integer id, Integer age) {
		// TODO Auto-generated method stub
		objCust.update(id, age);
	}

	}
