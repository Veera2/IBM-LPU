package com.example.restcontroller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.DAO.CustomerImpDAO;
import com.example.DAO.CustomerMapper;
import com.example.DAO.InvoiceImpDAO;
import com.example.DAO.InvoiceMapper;
import com.example.DTO.Customer;
import com.example.DTO.Invoice;

public class InvoiceController
{
Logger logger = LoggerFactory.getLogger(InvoiceImpDAO.class);
	
	@Autowired
	private JdbcTemplate jdbcTemplateObject;
	@GetMapping("/Invoice")
	
	/*
	 * @RequestMapping(produces = MediaType.APPLICATION_JSON, method =
	 * RequestMethod.GET, value = "/details")
	 */
@ResponseBody
	public List<Invoice> listInvoice()
	{
		String SQL="select * from customer";
		List<Invoice> invoice=jdbcTemplateObject.query(SQL, new InvoiceMapper());
		logger.debug("in debug");
		// TODO Auto-generated method stub
		return invoice;
	}


}
