package com.example.service;

import java.util.List;

import com.example.DTO.Customer;

public interface CustomerService 
{
	public  Customer getCustomerService(Integer id);
	  
	   public List<Customer> listCustomerService();
	  
	   public void deleteService(Integer id);
	  
	   public void updateService(Integer id, Integer age);
	   
	   public void createService(String name,Integer age);

}
