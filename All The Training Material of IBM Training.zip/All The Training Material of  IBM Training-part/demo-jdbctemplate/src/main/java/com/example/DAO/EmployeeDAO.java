package com.example.DAO;

import java.util.List;

import com.example.DTO.Employee;
public interface EmployeeDAO 
{

public Employee getEmployee(Integer id);

public List<Employee> listEmployees();

public void delete(Integer id);
public void update(Integer id,Integer age);
public void create(String name,Integer age);


}
