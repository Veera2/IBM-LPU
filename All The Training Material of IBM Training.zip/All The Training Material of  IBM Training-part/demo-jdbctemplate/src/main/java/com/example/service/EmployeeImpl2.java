
package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.DAO.EmployeeImpDAO;
import com.example.DTO.Employee;

@Service
public class EmployeeImpl2 implements EmployeeService 
{
@Autowired
private EmployeeImpDAO objEmp;

public void setDB()
{
	objEmp.setupDB();
}
@Override
public void createEmpService(String name, Integer age) 
{
	
	objEmp.create(name, age);

}
	@Override
	public Employee getEmployeeService(Integer id) 
	{
		
		return objEmp.getEmployee(id);
	}

	@Override
	public List<Employee> listEmployeeservice() 
	{
		
		
		return objEmp.listEmployees(); 
	}


	@Override
	public void updateEmpService(Integer id, Integer age) 
	{
		objEmp.update(id, age);

	}

	@Override
	public void deleteEmpService(Integer id) 
	{
		
		objEmp.delete(id);

	}
	
}
