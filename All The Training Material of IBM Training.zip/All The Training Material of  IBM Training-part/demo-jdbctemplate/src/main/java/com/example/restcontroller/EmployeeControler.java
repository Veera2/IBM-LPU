package com.example.restcontroller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.DAO.CustomerImpDAO;
import com.example.DAO.CustomerMapper;
import com.example.DAO.EmployeeImpDAO;
import com.example.DAO.EmployeeMapper;
import com.example.DTO.Customer;
import com.example.DTO.Employee;

public class EmployeeControler
{
	
Logger logger = LoggerFactory.getLogger(EmployeeImpDAO.class);
	
	@Autowired
	private JdbcTemplate jdbcTemplateObject;
	@GetMapping("/Employee")
	
	/*
	 * @RequestMapping(produces = MediaType.APPLICATION_JSON, method =
	 * RequestMethod.GET, value = "/details")
	 */
@ResponseBody
	public List<Employee> listEmployee()
	{
		String SQL="select * from customer";
		List<Employee> employ=jdbcTemplateObject.query(SQL, new EmployeeMapper());
		logger.debug("in debug");
		// TODO Auto-generated method stub
		return employ;
	}



}
