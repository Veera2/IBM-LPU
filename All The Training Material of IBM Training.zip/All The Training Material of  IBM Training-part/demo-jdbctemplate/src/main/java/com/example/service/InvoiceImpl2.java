package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.DAO.InvoiceImpDAO;
import com.example.DTO.Invoice;

@Service
public class InvoiceImpl2 implements InvoiceService {


@Autowired
private InvoiceImpDAO objInv;

public void setDB()
{
	objInv.setupDB();
}

	
	@Override
	public void createService(String name, Integer age)
	{
		// TODO Auto-generated method stub
		objInv.create(name, age);
	}

	@Override
	public Invoice getInvoiceService(Integer id) {
		// TODO Auto-generated method stub
		return objInv.getInvoice(id);
	}

	@Override
	public List<Invoice> listInvoiceService() {
		// TODO Auto-generated method stub
		return objInv.listInvoice();
	}

	@Override
	public void deleteService(Integer id) {
		// TODO Auto-generated method stub
		objInv.delete(id);
	}

	@Override
	public void updateService(Integer id, Integer age) {
		// TODO Auto-generated method stub
		objInv.update(id, age);
	}

}
