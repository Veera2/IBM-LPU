package com.example.service;

import java.util.List;

import com.example.DTO.Employee;

public interface EmployeeService
{
	

public Employee getEmployeeService(Integer id);

public List<Employee> listEmployeeservice();

public void deleteEmpService(Integer id);
public void updateEmpService(Integer id,Integer age);
public void createEmpService(String name,Integer age);


}
