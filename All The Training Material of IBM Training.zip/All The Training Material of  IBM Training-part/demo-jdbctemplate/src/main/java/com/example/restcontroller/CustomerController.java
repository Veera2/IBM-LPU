package com.example.restcontroller;

import java.util.List;


//import javax.ws.rs.core.MediaType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.ResourceAccessException;

import com.example.DAO.CustomerImpDAO;
import com.example.DAO.CustomerMapper;
import com.example.DTO.Customer;
import com.example.service.CustomerService;

@RestController
public class CustomerController
{
	
//Logger logger = LoggerFactory.getLogger(CustomerController.class);
	
	@Autowired
	private CustomerService custService;
	@GetMapping("/Customer")
	
	public List<Customer> listCustomer()
	{	
		return custService.listCustomerService();
	}
	
	@RequestMapping(method = RequestMethod.GET,value="/details/{id}")
	public Customer getCustomer(@PathVariable("id") Integer id) 
	{

	return custService.getCustomerService(id);	
		}
	
	@RequestMapping( method = RequestMethod.DELETE,  value = "/delete/{id}")
	@ResponseBody
	public ResponseEntity<Void> delete(@PathVariable("id") Integer id)
	{
		try
		{
		custService.deleteService(id);
		return ResponseEntity.ok().build();
		}
		catch(ResourceAccessException e)
		{
			return ResponseEntity.notFound().build();
		}
	}
	@RequestMapping( method = RequestMethod.PUT,  value = "/update/{id} {age}")
	@ResponseBody
	public ResponseEntity<Void> update(@PathVariable("id") Integer id, @PathVariable("age") Integer age)
	{
		try
		{
		custService.updateService(id, age);
		return ResponseEntity.ok().build();
		}
		catch(ResourceAccessException e)
		{
			return ResponseEntity.notFound().build();
		}
	}
	@RequestMapping( method = RequestMethod.POST,  value = "/create/{name} {age}")
	@ResponseBody
	public ResponseEntity<Void> create(@PathVariable("name") String name,@PathVariable("age") Integer age)
	{
		try
		{
		custService.createService(name, age);
		return ResponseEntity.ok().build();
		}
		catch(ResourceAccessException e)
		{
			return ResponseEntity.notFound().build();
		}
	}
	
	
	 
	 
}
