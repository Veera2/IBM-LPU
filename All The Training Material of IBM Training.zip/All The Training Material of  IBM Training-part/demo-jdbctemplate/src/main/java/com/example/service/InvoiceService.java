package com.example.service;

import java.util.List;

import com.example.DTO.Invoice;

public interface InvoiceService
{
	   public void createService(String name,Integer age);
	 public Invoice getInvoiceService(Integer id);
	  
	   public List<Invoice> listInvoiceService();
	  
	   public void deleteService(Integer id);
	  
	   public void updateService(Integer id, Integer age);
	   




}
