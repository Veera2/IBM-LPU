package com.example.dem;

/*

  package com.example.demo;

import java.util.*;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.example.DTO.Customer;
import com.example.DTO.Employee;
import com.example.DTO.Invoice;
import com.example.service.CustomerImpl2;
import com.example.service.EmployeeImpl2;
import com.example.service.InvoiceImpl2;

  

@Configuration
@EnableWebMvc
@ComponentScan({"com.example.restController"})

  @SpringBootApplication 
  public class dummyapp {
  
  public static void main(String[] args) {
  
  //SpringApplication.run(DemoTrainingJdbctemplateApplication.class, args);
  //SpringApplication.run(DemoTrainingKoeingJdbcTemplateApplication.class,
  
  
  
  ApplicationContext context=SpringApplication.run(DemoAppConfig.class, args);
  
  // remaining code will write after the break
  
  // perform operation @Employee
  
  EmployeeImpl2 employeeJDBCTemplate = context.getBean(EmployeeImpl2.class); 
  CustomerImpl2  customerJDBCTemplate=context.getBean(CustomerImpl2.class);
  InvoiceImpl2  invoiceJDBCTemplate=context.getBean(InvoiceImpl2.class);
  
  // method call here 
  //runEmployeeCRUD(employeeJDBCTemplate);
  //runCustomerCRUD(customerJDBCTemplate);
  //runInvoiceCRUD(invoiceJDBCTemplate); 
  Scanner sc=new Scanner(System.in);
  System.out.println("woud you like to enter 1 for yes 2 for no");
  System.out.println("enter your choice");
   int  iTmp=sc.nextInt(); 
  while(iTmp==1) 
  {
  
  System.out.println("1.Employee\n2.Customer\n3.Invoice\n4.Exit");
  System.out.println("enter your choice"); 
  int choice=sc.nextInt();
  
  switch(choice) 
  {
  case 1: 
	  //runEmployeeCRUD(employeeJDBCTemplate);
  
	  
	  // sc=new Scanner(System.in);
	  employeeJDBCTemplate.setDB();
	  
	  int iTmp1=444; 
	  while(iTmp1!=6) 
	  {
	  
	  System.out.println("1.Insertion\n2.Listing multiple Records\n3.Updating Record\n4.Listing single record\n5.Deleting the Record\n6.Exit"); 
	  System.out.println("enter your choice");
	  iTmp1=sc.nextInt(); 
	  switch(iTmp1) 
	  {
	  case 1: 
			  	{
			  		
				  System.out.println("------Records Creation--------");
				  employeeJDBCTemplate.createEmpService("siddu", 11);
				  employeeJDBCTemplate.createEmpService("bano", 2);
				  employeeJDBCTemplate.createEmpService("gridhar", 15);
				  }
			  break; 
	  case 2: 
			  	{
			  		
			  System.out.println("------Listing Multiple Records--------");
			  List<Employee>  employees = employeeJDBCTemplate.listEmployeeservice(); 
			  for (Employee record :  employees) 
			  { System.out.print("ID : " + record.getId());
			  System.out.print(", Name : " + record.getName());
			  System.out.println(", Age : " + record.getAge()); 
			  }
			  
			   }
			  break; 
	  case 3: 
			  {
			  System.out.println("----Updating Record with ID = 2 -----");
			  employeeJDBCTemplate.updateEmpService(2, 20);
			  
			  }
			  break;
	  case 4:
			  {
			  System.out.println("----Listing Record with ID = 2 -----");
			  
			  Employee employee = employeeJDBCTemplate.getEmployeeService(2);
			  System.out.print("ID : " + employee.getId()); System.out.print(", Name : " + employee.getName()); System.out.println(", Age : " + employee.getAge());
			  
			  }
			  break;
			  
	  case 5: 
			  {
			  System.out.println("--------Deleteting the record with id=2------");
			  employeeJDBCTemplate.deleteEmpService(2);
			  
			  } 
			  break;
	  case 6: break;
	  
	  }
	  }
	  
  
	   break;
  case 2:
  
	  customerJDBCTemplate.setDB();
	  
	  int iTmp2=444; 
	  while(iTmp2!=6) 
	  {
	  
	  System.out.println("1.Insertion\n2.Listing multiple Records\n3.Updating Record\n4.Listing single record\n5.Deleting the Record\n6.Exit"); 
	  System.out.println("enter your choice"); 
	  iTmp2=sc.nextInt();
	  switch(iTmp2) 
	  {
	  case 1: 
			  { 
				  System.out.println("******customer Record creation********");
			  customerJDBCTemplate.createService("Rajesh", 21);
			  customerJDBCTemplate.createService("Rakesh", 25);
			  customerJDBCTemplate.createService("Vanitha", 20);
			  customerJDBCTemplate.createService("Rani", 23); } 
			  break; 
	  case 2:
			  {
			  System.out.println("*****Listing multiple records of customer********");
			  List<Customer> customers=customerJDBCTemplate.listCustomerService(); 
			  for(Customer record: customers)
			  { System.out.print("ID : " + record.getId());
			  System.out.print(", Name : " + record.getName());
			  System.out.println(", Age : " + record.getAge());
			  
			  } 
			  } 
			  break;
	  case 3: 
			  {
			  System.out.println("******************UPDATED RECORD WITH ID=3*********");
			  customerJDBCTemplate.updateService(3, 19);
			  }
			  break;
	  case 4:
			  {
			  System.out.println("*************LISTING RECORD WITH ID=3******"); 
			  Customer customer=customerJDBCTemplate.getCustomerService(3); 
			  System.out.print("ID : " + customer.getId());
			  System.out.print(", Name : " + customer.getName());
			  System.out.println(", Age : " + customer.getAge());
			  } 
			  break;
	  case 5:
			  {
			  System.out.println("*****Deleting Record with id=3");
			  customerJDBCTemplate.deleteService(2);
			  } 
			  break;
	  case 6:break;
	  }
	  }
	  
  
	//  runCustomerCRUD(customerJDBCTemplate);
	  break;
  case 3:
  
	  invoiceJDBCTemplate.setDB();
	  
	  int iTmp3=444;
	  while(iTmp3!=6)
	  {
	  
	  System.out.println("1.Insertion\n2.Listing multiple Records\n3.Updating Record\n4.Listing single record\n5.Deleting the Record\n6.Exit");
	  System.out.println("enter your choice"); 
	  iTmp3=sc.nextInt();
	  switch(iTmp3) 
	  {
	  case 1: 
			  { 
				  System.out.println("++++++++Invoice Record Creation++++++");
			  invoiceJDBCTemplate.createService("Srihari", 21);
			  invoiceJDBCTemplate.createService("Bharath", 22);
			  invoiceJDBCTemplate.createService("Koushik", 21); 
			  } 
			  break; 
	  case 2:
			  {
			  System.out.println("+++++++Listing multiple records+++++++");
			  List<Invoice>  invoices=invoiceJDBCTemplate.listInvoiceService(); 
			  for(Invoice record: invoices) 
			  {
			  System.out.print("ID : " + record.getId());
			  System.out.print(", Name : " +  record.getName()); 
			  System.out.println(", Age : " + record.getAge()); } }
			  break; 
	  case 3:
		  {
		  
		  System.out.println("+++++++Updating Record with ID = 2+++++++");
		  invoiceJDBCTemplate.updateService(2, 20); 
		  }
		  break;
	  case 4:
			  {
			  System.out.println("+++++++Listing Record with ID = 2 ++++++++");
			  
			  Invoice invoice= invoiceJDBCTemplate.getInvoiceService(2); 
			  System.out.print("ID : " + invoice.getId()); 
			  System.out.print(", Name : " + invoice.getName());
			  System.out.println(", Age : " + invoice.getAge()); 
			  }
			  break;
	  case 5:
			  {
			  System.out.println("+++++++Deleteting the record with id=2++++++");
			  invoiceJDBCTemplate.deleteService(1); 
			  } 
			  break;
	  case 6:break;
	  } 
	  }
  
	  //runInvoiceCRUD(invoiceJDBCTemplate); 
	  break;
  
  } 
  } 
  }
   
  } 
  
  */
  




  /*
  public static void runEmployeeCRUD(EmployeeImpDAO employeeJDBCTemplate)
  {
  
  // create the employee data 
	
  }
  public static void runCustomerCRUD(CustomerImpDAO customerJDBCTemplate)
  {
  
  //Scanner sc=new Scanner(System.in); 
   
  } 
  
  public static void runInvoiceCRUD(InvoiceImpDAO invoiceJDBCTemplate)
  {
  Scanner sc=new Scanner(System.in); 
  }
  
    
  */
  
  
  
  
  
 