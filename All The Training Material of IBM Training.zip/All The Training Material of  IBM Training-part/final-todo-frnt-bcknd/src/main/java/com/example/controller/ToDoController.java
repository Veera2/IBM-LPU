package com.example.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.dao.ToDoDao;
import com.example.entity.ToDo;
import com.example.exception.ResourceNotFoundException;




@RestController
@RequestMapping("/api/v1")
@CrossOrigin(origins="*")
public class ToDoController {

	@Autowired
	private ToDoDao todoDao;
	
	@GetMapping("/todos")
    public List<ToDo> getAlltodos() {
        return todoDao.findAll();
    }

    @GetMapping("/todos/{name}")
    public ResponseEntity<ToDo> gettodoByName(@PathVariable(value = "todoName") String todoName)
        throws ResourceNotFoundException {
        ToDo objToDo=todoDao.findById(todoName)
          .orElseThrow(() -> new ResourceNotFoundException("todo not found for this name :: " + todoName));
        return ResponseEntity.ok().body(objToDo);
    }
    
    @PostMapping("/todos")
    public ToDo createToDo(@Valid @RequestBody ToDo objToDo) {
        return todoDao.save(objToDo);
    }

    @PutMapping("/todos/{name}")
    public ResponseEntity<ToDo> updatetodoName(@PathVariable(value = "todoName") String todoName,
         @Valid @RequestBody ToDo todoDetails) throws ResourceNotFoundException {
        ToDo todo =todoDao.findById(todoName)
        .orElseThrow(() -> new ResourceNotFoundException("Employee not found for this id :: " + todoName));

        todo.setTodoName(todoDetails.getTodoName());
        todo.setTodoDescription(todoDetails.getTodoDescription() );
        
        final ToDo updatedtodo = todoDao.save(todo);
        return ResponseEntity.ok(updatedtodo);
    }

    @DeleteMapping("/todos/{name}")
    public Map<String, Boolean> deletetodo(@PathVariable(value = "name") String todoName)
         throws ResourceNotFoundException {
        ToDo todo =todoDao.findById(todoName)
       .orElseThrow(() -> new ResourceNotFoundException("Employee not found for this id :: " + todoName));

        todoDao.delete(todo);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return response;
    }

}
