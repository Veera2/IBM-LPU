package com.example.entity;

public class ToDo 
{
	public String todoName;
	public String todoDescription;
	public String getTodoName() {
		return todoName;
	}
	public void setTodoName(String todoName) {
		this.todoName = todoName;
	}
	public String getTodoDescription() {
		return todoDescription;
	}
	public void setTodoDescription(String todoDescription) {
		this.todoDescription = todoDescription;
	}
	public ToDo(String todoName, String todoDescription) {
		super();
		this.todoName = todoName;
		this.todoDescription = todoDescription;
	}
	public ToDo() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
