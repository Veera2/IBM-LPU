package fi.collect;

public class Dataset 
{
int num1;

public Dataset(int num1) {
	super();
	this.num1 = num1;
}
	/*
	 * @Override public int compareTo(Dataset o) {
	 * 
	 * if(num1>o.num1) return 1; else if(num1<o.num1) return -1; else return 0; }
	 * public String ToString() { String str=String.valueOf(num1);
	 * 
	 * 
	 * return str; }
	 */
public String ToString() 
{
	return String.valueOf(num1);
}
}
