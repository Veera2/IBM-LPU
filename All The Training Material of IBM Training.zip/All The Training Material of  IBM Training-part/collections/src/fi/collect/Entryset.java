package fi.collect;

import java.util.Set;
import java.util.TreeSet;

public class Entryset 
{
public static void main(String args[])
{
	
	Set<Dataset> set=new TreeSet<>(new DataComparator());
	set.add(new Dataset(4));
	set.add(new Dataset(1));
	set.add(new Dataset(10));
	set.add(new Dataset(6));
	set.add(new Dataset(2));
	
	System.out.println(set);
	 
}
}
