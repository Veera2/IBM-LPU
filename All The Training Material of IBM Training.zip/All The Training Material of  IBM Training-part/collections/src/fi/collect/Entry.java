
  package fi.collect;
  
  import java.util.Collections; import java.util.Iterator; import
  java.util.LinkedList; import java.util.List;
  
  public class Entry {
  
  public static void main(String[] args) { List<Integer> list=new
  LinkedList<>();
  
  list.add(7); list.add(2); list.add(3); list.add(8); list.add(9); list.add(2);
  Iterator<Integer> iter=list.iterator();
  
  
  while(iter.hasNext()) { Integer obj=iter.next(); System.out.println(obj); }
  System.out.println("iterator implemented"); Collections.sort(list);
  Iterator<Integer> listIter=list.listIterator(); while(iter.hasNext()) {
  Integer obj=listIter.next(); System.out.println(obj); }
  System.out.println(listIter.hashCode());
  
  
  
  }
  
  }
 