package fi.collect;

import java.util.Comparator;

public class DataComparator implements Comparator<Dataset>
{

	@Override
	public int compare(Dataset o1, Dataset o2)
	{
		if(o1.num1>o2.num1)
			return 1;
		else if(o1.num1<o2.num1)
			return -1;
		else
			return 0;
	}

}
