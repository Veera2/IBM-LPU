/*
 * package fi.collect;
 * 
 * import java.util.Iterator; import java.util.LinkedList; import
 * java.util.List;
 * 
 * public class Initializer {
 * 
 * public static Iterator<Integer> Intializer() { List<Integer> list=new
 * LinkedList<>();
 * 
 * list.add(7); list.add(2); list.add(3); list.add(8); list.add(9); list.add(2);
 * 
 * 
 * 
 * return list.iterator(); } }
 */