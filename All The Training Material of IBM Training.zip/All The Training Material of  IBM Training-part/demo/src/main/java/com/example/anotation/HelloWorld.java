package com.example.anotation;

public interface HelloWorld 
{

	//declaration of services
	public String printHello(String msg);
	
}
