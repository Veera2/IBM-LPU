package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Import;

import com.example.anotation.AppConfig;
import com.example.anotation.HelloWorld;


//its an entry for the application
@SpringBootApplication
@EnableAutoConfiguration
@ComponentScan({"com.example"})
@Import({AppConfig.class})
public class DemoApplication {

	public static void main(String[] args) 
	{
		ApplicationContext ctx=SpringApplication.run(AppConfig.class);
		HelloWorld obj=(HelloWorld) ctx.getBean("helloBean");
		System.out.println(obj.printHello("my annotation spring"));
		
	}

}
