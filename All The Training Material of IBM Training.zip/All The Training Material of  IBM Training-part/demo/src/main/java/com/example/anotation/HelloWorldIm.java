package com.example.anotation;

import org.springframework.stereotype.Component;

@Component
public class HelloWorldIm implements HelloWorld
{

	@Override
	public String printHello(String msg) {
		// TODO Auto-generated method stub
		System.out.println("in print method here--->");
		return "Hello--->"+msg;
	}

	
}
