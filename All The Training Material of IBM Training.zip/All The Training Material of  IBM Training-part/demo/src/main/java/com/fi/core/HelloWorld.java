package com.fi.core;

public class HelloWorld
{
	//defining the property here
private String message;

//injecting the setter method here
public void setMessage(String message) {
	this.message = message;
}
//here is the custom method to show the value
public void display()
{
	System.out.println(message);
}
}
