package com.fi.core;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class HellWorldApp {

	public static void main(String[] args) 
	{
	//look up the spring application using the application context in spring
		
		 ApplicationContext ctx=new ClassPathXmlApplicationContext("beans.xml");
		 HelloWorld objHello=(HelloWorld) ctx.getBean("helloWorld");
		 objHello.display();
	}

}
