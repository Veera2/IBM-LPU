package com.example.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Customer 
{
private String name;
private String adress;
private int id;
Order objOrder;

@XmlElement
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
@XmlElement
public Order getObjOrder() {
	return objOrder;
}
public void setObjOrder(Order objOrder) {
	this.objOrder = objOrder;
}
@XmlElement
public String getAdress() {
	return adress;
}
public void setAdress(String adress) {
	this.adress = adress;
}
@XmlElement
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}


		
}
