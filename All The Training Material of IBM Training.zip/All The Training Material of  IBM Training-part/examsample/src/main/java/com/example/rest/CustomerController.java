package com.example.rest;

import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


import com.example.dto.Customer;

import com.example.dto.Order;

@RestController
public class CustomerController 
{

	@GetMapping("/customerorder")
	public String getCustomer() 
	{
		return "welcome to customer ";
	}
		
@RequestMapping(produces = MediaType.APPLICATION_XML, method = RequestMethod.GET, value = "/customerdetails")
@ResponseBody
	public Customer getdetails()
{
		
		Customer objCustomer=new Customer();
		Order o1=new Order();
		
		objCustomer.setName("veeranjaneyulu");
		objCustomer.setAdress("jalandhar,lpu");
		objCustomer.setId(1);
			
		o1.setProductName("ONEPLUS");
		o1.setProductId(12);
		o1.setCostOfBill(35000);
		objCustomer.setObjOrder(o1);
		
		return objCustomer;
		
		}


@RequestMapping(produces = MediaType.APPLICATION_XML, method = RequestMethod.GET, value = "/orderdetails")
@ResponseBody
	public Order details()
{
		
		Order objOrder=new Order();
		
		objOrder.setProductName("ONEPLUS");
		objOrder.setProductId(12);
		objOrder.setCostOfBill(35000);
		return objOrder;
		
		}


		
		




}
