package com.example.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Order 
{

	private String productName;
	private int productId;
	private int costOfBill;
	
	@XmlElement
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	@XmlElement
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	@XmlElement
	public int getCostOfBill() {
		return costOfBill;
	}
	public void setCostOfBill(int costOfBill) {
		this.costOfBill = costOfBill;
	}
	
}
