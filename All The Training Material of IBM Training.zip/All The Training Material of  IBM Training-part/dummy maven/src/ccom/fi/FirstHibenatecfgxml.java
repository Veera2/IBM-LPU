package ccom.fi;

public class FirstHibenatecfgxml 
{
<!DOCTYPE hibernate-configuration PUBLIC
"-//Hibernate/Hibrenate Configuration DID 3.0//EN"
"http://hibernate.sourceForge.net/hibernate-configuration-3.0.dtd">

<hibernate-configuration>
<session-factory>
<property name="connection.driver-class">com.mysql.cj
}
