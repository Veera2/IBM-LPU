
public class Program {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
			
			System.out.println("enter the date");
			SubProgram obj=new SubProgram();
			obj.day=ConsoleInput.getInt();
			obj.getDay();
			System.out.println("enter the month");
			obj.month=ConsoleInput.getInt();
			obj.getMonth();
			System.out.println("enter year");
			obj.year=ConsoleInput.getInt();
			obj.getYear();
			System.out.println("the valid date is: "+obj.getDay()+"/"+obj.getMonth()+"/"+obj.getYear());
			
	}

}
