package com.fi.First_Hibernate;

import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        Configuration config=new Configuration();
        config.configure("First-Hibernate.cfg.xml");
        
        SessionFactory factory=config.buildSessionFactory();
        /*try(Session session=factory.openSession())
        {
        	Category objCategory=(Category)session.load(Category.class,1);
        	System.out.println(objCategory.getCategoryName());
        	System.out.println(objCategory.getCategoryDescription());
        	System.out.println(objCategory.getCategoryImageUrl());
        }
        catch(Exception e)
        {
        	e.printStackTrace();
        }*/
        
        //for storing object
        try(Session session=factory.openSession();
        		Scanner sc=new Scanner(System.in))
        {
        	System.out.println("enter the id");
        	int id=sc.nextInt();
        	System.out.println("enter the name");
        	String name=sc.next();
        	System.out.println("enter the description");
        	String desc=sc.next();
        	System.out.println("enter the image url");
        	String image=sc.next();
        	
        	Category objCategory=new Category(id,name,desc,image);
        	System.out.println("object stored successfull");
        	
        	Transaction tx=session.beginTransaction();
        	session.save(objCategory);
        	tx.commit();
        }
        catch(HibernateException hiber)
        {
        	hiber.printStackTrace();
        	
        }
    }
}