package fi.annot;
@serialInfo(name="value",versionId=11)
public class Data 
{
@serialInfo(name="value",versionId=11)
	public int value;
	public String stringvalue;
	public  float floatData=9.8f;
	
	
	public void display()
	{
		
	System.out.println("the value is : "+value);	
	System.out.println("the privagte Data: "+floatData);
	System.out.println("protected data: "+stringvalue);
	System.out.println("Annotations invoked");
	}

}
