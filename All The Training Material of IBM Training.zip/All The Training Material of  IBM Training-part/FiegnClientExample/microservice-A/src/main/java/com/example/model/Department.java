package com.example.model;



import lombok.Data;

@Data
public class Department {

	private int id;

	private String departmentName;
	

}
