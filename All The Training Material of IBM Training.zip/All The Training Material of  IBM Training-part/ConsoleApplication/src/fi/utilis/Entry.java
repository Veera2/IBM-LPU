package fi.utilis;

import java.lang.Math;
//import java.util.Random;
import fi.utility.LinkedList;
//import java.util.LinkedList;


 public class Entry {
 
 
 public static int randomInteger(int min, int max) 
 {
	 int x = (int)  (Math.random() * ((max - min) + 1)) + min; return x;
 } 
 
 public static void main(String args[])
 {
 LinkedList objList = new LinkedList();
 //Entry obj = new Entry();
 
 System.out.println("enter thr maximum number");
 int  maximum=ConsoleInput.getInt();
 int generatedNumber=randomInteger(1,maximum);
 objList.addNode(generatedNumber);
 System.out.println(generatedNumber);
 
 
 
 }
 }
 