package fi.utilis;


/*Create a java console application that will generate random numbers and store it in the LinkedList (You can use the LinkedList created by us in class).  The Random numbers will be generated from 1 to N where N will be the maximum value accepted from the user.

(Hint, Use the java.lang.Math class for generation of Random Numbers)
*/


public class ConsoleInput
{
	public static String getString() 
	{
		try
		{
			
			byte input []= new byte [100];
			int length= System.in.read(input);
			byte [] arrfinal =new byte [length-2];
			System.arraycopy(input, 0,arrfinal,0, length-2);
			
			String objstring =new String(arrfinal);
			//System.out.println("value entered is "+objstring);
			return objstring;
		}
		catch (Exception objException)
		{
			System.out.println(objException);
		}
		return null;
		
	
	}
		
		public static float getFloat()
		{
			String objstring = getString();
			float num1 = Float.parseFloat(objstring);
			
			return num1;
			
		}
		public static int getInt()
		{
			String objstring = getString();
			int num1= Integer.parseInt(objstring);
			return num1;
		
	}
		public static boolean getBoolean()
		{
			String objstring=getString();
			boolean num1=Boolean.parseBoolean(objstring);
			return num1;
		}
	
	

}

