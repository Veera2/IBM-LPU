package fi.utilis;

public class Entry1 {

	public static void main(String[] args)
	{
	System.out.println("enter the name of the package");
	String Package=ConsoleInput.getString();
	System.out.println("enter the name of the class");
	String clas=ConsoleInput.getString();

	}

}
