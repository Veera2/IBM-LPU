package com.example.rest;

import javax.ws.rs.core.MediaType;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.dto.Customer;

@RestController
// @XmlRootElement
public class RestCustomerController
{
	@GetMapping("/customer")
	public String getCustomer() {
		return "My Hello Rest";
	}
		
@RequestMapping(produces = MediaType.APPLICATION_XML, //Application.Json for jsonfiles
    method = RequestMethod.GET,
    value = "/details")
@ResponseBody
	public Customer details(){
		
		Customer c1=new Customer();
//		c1.setId(21);
//		c1.setName("Amit");
//		c1.setAddress("Noida");
		c1.setId(12);
		c1.setName("rajesh");
		c1.setAddress("nirmal");
		
		return c1;
		
	}

	
}
