package fi.exam;

//Create a Java console Application that creates a POJO class representing the details of a Mobile Phone [fields such as, Mobile Id, Mobile Name, Mobile Make, Operating System, RAM (Numeric), Internal Storage (Numeric � 32,64,128),Screen Size (Numeric)] will be accepted from the user.  
//Once the user enters the value the MobilePhone Object will be stored in a Collection object (Use your LinkedList class).  Option 2 will allow the user to list all the Mobile Phone objects stored in the Collection Object.

public class Pojo
{
	
int mobileId;
String mobileName;
String mobileMake;
String operatingSystem;
int ram;
int  internalStorage;
int screenSize;
public int getMobileId() {
	return mobileId;
}
public void setMobileId(int mobileId) {
	this.mobileId = mobileId;
}
public String getMobileName() {
	return mobileName;
}
public void setMobileName(String mobileName) {
	this.mobileName = mobileName;
}
public String getMobileMake() {
	return mobileMake;
}
public void setMobileMake(String mobileMake) {
	this.mobileMake = mobileMake;
}
public String getOperatingSystem() {
	return operatingSystem;
}
public void setOperatingSystem(String operatingSystem) {
	this.operatingSystem = operatingSystem;
}
public int getRam() {
	return ram;
}
public void setRam(int ram) {
	this.ram = ram;
}
public int getInternalStorage() {
	return internalStorage;
}
public void setInternalStorage(int internalStorage) {
	this.internalStorage = internalStorage;
}
public int getScreenSize() {
	return screenSize;
}
public void setScreenSize(int screenSize) {
	this.screenSize = screenSize;
}

}
