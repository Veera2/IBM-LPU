package fi.exam;


import org.fi.utils.ConsoleInput;

import fi.utility.LinkedList;


public class Entry
{
public static void main(String args[])
{
/*	mobileId;
	String mobileName;
	String mobileMake;
	String operatingSystem;
	int ram;
	int  internalStorage=3264128;
	int screenSize;*/
	
	
	
	System.out.println("would you like to enter 1 for yes 2 for no");
	int temp=ConsoleInput.getInt();
	while(temp==1)
	{
		System.out.println("1.add details\n2.list the mobile objects\n3.exit");
		int choice=ConsoleInput.getInt();
		switch(choice)
		{
		case 1:
		{
			
			LinkedList objList=new LinkedList();
			
			System.out.println(" enter the mobile id ");
			int mobileId=ConsoleInput.getInt();
			System.out.println("enter the mobile Name");
			String mobileName=ConsoleInput.getString();
			System.out.println("enter the mobile maker");
			String mobileMake=ConsoleInput.getString();
			System.out.println("enetr the name of the operating System");
			String operatingSystem=ConsoleInput.getString();
			System.out.println("enter the ram");
			int ram=ConsoleInput.getInt();
			System.out.println("enter the internalStorage");
			int internalStorage=ConsoleInput.getInt();
			System.out.println("enter the Screensize");
			int screenSize=ConsoleInput.getInt();
			 Pojo obj=new Pojo();
			 
			objList.addNode(obj.getMobileId());
			objList.addNode(obj.getMobileName());
			objList.addNode(obj.getMobileMake());
			objList.addNode(obj.getOperatingSystem());
			objList.addNode(obj.getRam());
			objList.addNode(obj.getInternalStorage());
			objList.addNode(obj.getScreenSize());
			
		}
		break;
		case 2:
		{
			
			LinkedList objList=new LinkedList();
			
			
			Pojo obj=(Pojo)objList.getFirst();
			System.out.println(obj.getMobileId());
			System.out.println(obj.getMobileMake());
			System.out.println(obj.getMobileName());
			System.out.println(obj.getOperatingSystem());
			System.out.println(obj.getRam());
			System.out.println(obj.getInternalStorage());
			System.out.println(obj.getScreenSize());
			
		}
		break;
		case 3: break;
		}
		
	}
	
	//System.out.println(mobileId+mobileName+operatingSystem+ram+internalStorage+screenSize);
	
		
		
		
	//System.out.println("enter the values of the obje")
	
}
}
